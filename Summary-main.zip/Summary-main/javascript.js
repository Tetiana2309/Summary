
  
 // Находим элемент по его ID
var portfolioItem = document.getElementById("portfolio-item");

// Добавляем обработчик события клика на элемент
portfolioItem.addEventListener("click", function() {
  // Перенаправляем пользователя на указанную ссылку при клике
  window.location.href = "https://tetiana2309.github.io/My_Portfolio/";
});